# Final-Project-Team-F
Payton Ullman, Patrick Newcomb, Michael Keen, Jacob Goelz
This project is our final for CS222. 
It is going to be an application that will help supply the user with random recipes that they can add filters to.

-In order to run project, you must set the main directory as "Sources Root" and the test directory as "Test Sources Root", and the JDK should be 8 to run optimally.

Warnings Suppressed:
Main.java, line 14. Constant Condition. The warning was alerting us that the functions may return a null, but in this case, they will not. 
RecipeSearch.java, several lines. Constant Condition, misspelling. Some functions may return null, but in this case, they do not. Additionally, misspellings were suppressed as well as redundant variable names, because even though it is redundant, it helps to keep the code clean and organized.

Due to issues with the server, the recipes shown may not match the ingredients and/or instructions. This is hopefully a temporary issue that will be resolved on the part of Spoonacular soon.
