package MainCode.Code;
import java.net.URL;
import java.net.URLConnection;

public class Internet {

    public String testConnection() {
        try {
            URL url = new URL("http://www.spoonacular.com");
            URLConnection connection = url.openConnection();
            connection.connect();
            return "Connection Successful";
        } catch (Exception e) {
            return "Internet not connected";
        }
    }
}
