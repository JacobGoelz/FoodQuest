package MainCode.Code;
import java.util.List;

@SuppressWarnings("Local variable name is redundant")
public class Recipe {
    private String recipeName;
    private String recipeInstructions;
    private List<String> recipeIngredients;
    public Recipe (String title, String instructions, List<String> ingredients){
        recipeName = title;
        recipeInstructions = instructions;
        recipeIngredients = ingredients;
    }
        public String getName(){
        return recipeName;
    }
    public String getInstructions(){
        return recipeInstructions;}
    public List<String> getIngredients(){
        return recipeIngredients;
    }
}

