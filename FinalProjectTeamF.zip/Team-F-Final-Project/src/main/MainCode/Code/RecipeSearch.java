package MainCode.Code;

//Please help with error: No Class definition found

import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.mashape.unirest.request.GetRequest;



public class RecipeSearch {
    @SuppressWarnings("unused")
    public JsonNode searchQuick() {
        GetRequest response;
        JsonNode data = null;
        response = Unirest.get("https://spoonacular-recipe-food-nutrition-v1.p.rapidapi.com/recipes/random?number=5&tags=quick")
                .header("X-RapidAPI-Key", "DrDXDcb3EHmshyY7TugbzK9zkE50p1qEEIOjsnxypx1iyDPAFY");
        try {

            data = response.asJson().getBody();

        } catch (UnirestException e) {
            e.printStackTrace();
        }
        return data;
    }


        }
