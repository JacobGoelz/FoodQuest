package MainCode.Code;

import com.google.gson.*;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RecipeParser {
    @SuppressWarnings("redundant")
    public List<Recipe> parse(String file) {
        JsonParser parser = new JsonParser();
        InputStream stream = new ByteArrayInputStream(file.getBytes());
        Reader reader = new InputStreamReader(stream);
        JsonElement element = parser.parse(reader);
        JsonObject object = element.getAsJsonObject();
        JsonArray array;
        List<Recipe> recipeTitles = new ArrayList<>();
        for (Map.Entry<String, JsonElement> entry : object.entrySet()){
            JsonElement entryObject = entry.getValue();
            array = entryObject.getAsJsonArray();
            addRecipesToList(array, recipeTitles);
        }
        return recipeTitles;
    }

    private void addRecipesToList(JsonArray array, List<Recipe> recipesList) {
        List<String> ingredients = new ArrayList<>();
        HashMap<String, List<String>> ingredientAndTitleList = new HashMap<>();
        String instructions = "";
        for (int i = 0; i < array.size(); i++) {
            String title = array.get(i).getAsJsonObject().get("title").getAsString();
            JsonArray innerArray = array.get(i).getAsJsonObject().get("analyzedInstructions").getAsJsonArray();
            for (int j = 0; j < innerArray.size(); j++) {
                JsonArray steps = innerArray.get(j).getAsJsonObject().get("steps").getAsJsonArray();
                for (int g = 0; g < steps.size(); g++) {
                    JsonArray jsonIngredients = steps.get(g).getAsJsonObject().get("ingredients").getAsJsonArray();
                    for (int k = 0; k < jsonIngredients.size(); k++) {
                        String name = jsonIngredients.get(k).getAsJsonObject().get("name").getAsString();
                        if (name != null) {
                            ingredients.add(name);
                        }
                        ingredientAndTitleList.put(title, ingredients);
                        instructions = array.get(i).getAsJsonObject().get("instructions").getAsString();
                        }
                    }
                }
            Recipe recipe = new Recipe(title, instructions, ingredientAndTitleList.get(title));
            recipesList.add(recipe);
            }
        }
    }



