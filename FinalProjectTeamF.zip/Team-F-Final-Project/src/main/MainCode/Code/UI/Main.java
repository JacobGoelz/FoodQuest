package MainCode.Code.UI;

import com.sun.javafx.css.StyleManager;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class Main extends Application{
    @SuppressWarnings("ConstantConditions")
    @Override
    public void start(Stage primaryStage) throws Exception {
        
        StyleManager.getInstance().addUserAgentStylesheet("ImportedFonts.css");
        Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("UI_recipes.fxml"));
        primaryStage.setTitle("Food Quest");
        Scene recipepage = new Scene(root, 790, 430);
        primaryStage.setScene(recipepage);
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    public static void main(String[] args){
        launch(args);
    }

}
