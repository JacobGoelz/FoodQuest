package MainCode.Code.UI;

import MainCode.Code.Internet;
import MainCode.Code.Recipe;
import MainCode.Code.RecipeParser;
import MainCode.Code.RecipeSearch;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import java.util.List;

public class Controller {

    public Button randomRecipeButton;
    public Button testConnectionButton;
    public Button ClearBox;
    @FXML
    private TextField connectionTextBox;
    @FXML
    private ListView<String> TextBox;

    @FXML
    private TextArea InstructionBox;
    @FXML
    private int i;
    private void print(){
        RecipeParser parser = new RecipeParser();
        RecipeSearch search = new RecipeSearch();
        List<Recipe> recipes = parser.parse(search.searchQuick().toString());
        String instructions = recipes.get(i).getInstructions();
        List<String> ingredients = recipes.get(i).getIngredients();
        InstructionBox.setText("Instructions:" + "\n" + instructions + "\n" + "Ingredients:" +"\n" + ingredients);
    }

    public void testConnection() {
        Internet connection = new Internet();
        connectionTextBox.setText(connection.testConnection());
    }
    public void showRecipe() {
        RecipeParser parser = new RecipeParser();
        RecipeSearch search = new RecipeSearch();
        List<Recipe> recipes = parser.parse(search.searchQuick().toString());
        for (Recipe recipe : recipes) {
            TextBox.getItems().addAll(recipe.getName());

        }
    }

    public void clear() {
        TextBox.getItems().clear();
        InstructionBox.clear();
    }

    @FXML
    public void initActions() {
        //Detecting mouse clicked
        TextBox.setOnMouseClicked(arg0 -> {
            //Check which list index is selected then set txtContent value for that index
            this.i = TextBox.getSelectionModel().getSelectedIndex();
            if (i < 5 ) {
                print();
        }
    });
}
}