package Code;


import MainCode.Code.*;
import com.mashape.unirest.http.JsonNode;
import org.junit.Assert;
import org.junit.Test;
import java.util.List;


public class Tests {

    @Test
    public void TestConnection(){
        Internet internet = new Internet();
        String message = internet.testConnection();
        Assert.assertEquals(message, "Connection Successful");
    }
    @Test
    public void TestRecipeGetTitle(){
        RecipeParser parser = new RecipeParser();
        RecipeSearch search = new RecipeSearch();
        JsonNode data = search.searchQuick();
        List<Recipe> recipes = parser.parse(data.toString());
        Recipe recipe = recipes.get(1);
        String title = recipe.getName();
        Assert.assertNotNull(title);
    }
    @Test
    public void TestRecipeGetInstructions(){
        RecipeParser parser = new RecipeParser();
        RecipeSearch search = new RecipeSearch();
        JsonNode data = search.searchQuick();
        List<Recipe> recipes = parser.parse(data.toString());
        Recipe recipe = recipes.get(1);
        String instructions = recipe.getInstructions();
        Assert.assertNotNull(instructions);
    }
    @Test
    public void TestRecipeIngredients(){
        RecipeParser parser = new RecipeParser();
        RecipeSearch search = new RecipeSearch();
        JsonNode data = search.searchQuick();
        List<Recipe> recipes = parser.parse(data.toString());
        Recipe recipe = recipes.get(1);
        List<String> ingredients = recipe.getIngredients();
        Assert.assertNotNull(ingredients);
    }
    @Test
    public void TestSearchQuickandRecipeParser(){
        RecipeSearch search = new RecipeSearch();
        RecipeParser parser = new RecipeParser();
        List<Recipe> recipes = parser.parse(search.searchQuick().toString());
        System.out.println(recipes);
    }

}
